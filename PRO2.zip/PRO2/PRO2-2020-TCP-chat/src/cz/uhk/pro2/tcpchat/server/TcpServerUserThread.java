package cz.uhk.pro2.tcpchat.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Thread that handles a single connected client
 */
public class TcpServerUserThread extends Thread {
    private final Socket connectedClientSocket;
    private final MessageBroacaster broacaster;

    public TcpServerUserThread(Socket connectedClientSocket, MessageBroacaster broadcaster) {
        this.connectedClientSocket = connectedClientSocket;
        this.broacaster = broadcaster;
    }

    @Override
    public void run() {
        try {
            InputStream is = connectedClientSocket.getInputStream();
            BufferedReader reader = new BufferedReader(new InputStreamReader(is));

            String message;
            while ((message  = reader.readLine()) != null) {
                if(message.startsWith("/"))
                    command(message);
                else {
                    System.out.println("New message received: " + message + " " + connectedClientSocket);
                    broacaster.broadcastMessage(message, connectedClientSocket);
                }
            }
            System.out.println("UserThread ended " + connectedClientSocket);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void command(String message){
        System.out.print("command");
        if(message == "/quit")
            message = null;
        if(message == "/time")
            broacaster.broadcastMessage(new Date().toString(), connectedClientSocket);
    }
}
