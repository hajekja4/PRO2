package cz.uhk.pro2.todo;

import cz.uhk.pro2.todo.gui.NewTaskWindow;
import cz.uhk.pro2.todo.gui.RemoveTaskWindow;
import cz.uhk.pro2.todo.gui.TasksTableModel;
import cz.uhk.pro2.todo.model.Task;
import cz.uhk.pro2.todo.model.TaskList;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TodoMain extends JFrame {
    private JButton btnAdd = new JButton("Přidat úkol");
    private JButton btnRemove = new JButton("Odstranit úkol");
    private JButton btnSaveJSON = new JButton("Uložit do JSON");
    private JButton btnSaveCSV = new JButton("Uložit do CSV");
    private JPanel pnlNorth = new JPanel();
    private JPanel pnlSouth = new JPanel();
    private TaskList taskList = new TaskList();
    private TasksTableModel tasksTableModel = new TasksTableModel(taskList);
    private JTable tbl = new JTable(tasksTableModel);
    private JLabel lblUndoneTasks = new JLabel();
    private NewTaskWindow newTaskWindow = new NewTaskWindow(taskList, tasksTableModel, lblUndoneTasks);
    private RemoveTaskWindow removeTaskWindow = new RemoveTaskWindow(taskList, tasksTableModel, lblUndoneTasks);

    public TodoMain() throws HeadlessException {
        setTitle("TODO app");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pnlNorth.add(btnAdd);
        pnlNorth.add(btnRemove);
        pnlNorth.add(lblUndoneTasks);
        add(pnlNorth, BorderLayout.NORTH);
        add(new JScrollPane(tbl), BorderLayout.CENTER);
        pnlSouth.add(btnSaveJSON);
        pnlSouth.add(btnSaveCSV);
        add(pnlSouth, BorderLayout.SOUTH);
        pack();
        btnAdd.addActionListener(e -> newTaskWindow.setVisible(true));
        btnRemove.addActionListener(e -> removeTaskWindow.setVisible(true));
        btnSaveJSON.addActionListener(e -> toJSON());
        btnSaveCSV.addActionListener(e -> toCSV());
        taskList.addTask(new Task("Naučit se Javu", new Date(), false));
        taskList.addTask(new Task("Jit se proběhnout", new Date(), false));
        taskList.addTask(new Task("Vyvařit roušku", new Date(), false));
        lblUndoneTasks.setText("Počet nesplněných úkolů: " + taskList.getUndoneTasksCount()); 
    }

    public void toJSON(){
        saveFile(taskList.toJSON());
    }

    public void toCSV(){
        String data = "";
        for(Task task : taskList.getTasks())
            data += task.getDescription() + ";" + task.getDueDate() + ";" + task.isDone() + "\n";
        saveFile(data);
    }

    public void saveFile(String data){
        JFileChooser j = new JFileChooser(); 
        j.showSaveDialog(null); 
        try {
            FileWriter writer = new FileWriter(j.getSelectedFile().getAbsolutePath(), Charset.forName("UTF-8"));
            writer.append(data);
            writer.flush();
            writer.close();
        }
        catch(Exception exception) {}
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                TodoMain window = new TodoMain();
                window.setVisible(true);
            }
        });
    }
}
