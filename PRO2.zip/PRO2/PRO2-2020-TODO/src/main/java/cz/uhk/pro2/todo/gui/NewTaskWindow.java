package cz.uhk.pro2.todo.gui;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;

import cz.uhk.pro2.todo.model.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import static javax.swing.JOptionPane.showMessageDialog;


public class NewTaskWindow extends JFrame {
    private JButton btnAdd = new JButton("Přidat úkol");
    private JPanel panel = new JPanel();
    private JTextField nameInput = new JTextField("Název úkolu");
    private JTextField dateInput = new JTextField("Datum");
    private TaskList list;
    private AbstractTableModel table;
    private JLabel lblUndoneTasks;

    public NewTaskWindow(TaskList list, AbstractTableModel table, JLabel lblUndoneTasks) {
        this.list = list;
        this.table = table;
        this.lblUndoneTasks = lblUndoneTasks;
        btnAdd.addActionListener(e -> addToList());
        setTitle("Add Task");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        panel.add(nameInput);
        panel.add(dateInput);
        panel.add(btnAdd);
        add(panel, BorderLayout.CENTER);
        pack();
    }

    private void addToList(){
        try{
            SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
            Date date = formatter.parse(dateInput.getText());
            list.addTask(new Task(nameInput.getText(), date, false));
            lblUndoneTasks.setText("Počet nesplněných úkolů: " + list.getUndoneTasksCount());
            this.setVisible(false);
            table.fireTableDataChanged();
        } catch(Exception e) {
            showMessageDialog(null, "Chyba parsování data. Datum zadávejte ve formátu dd.MM.yyyy");
        }
    }
}
