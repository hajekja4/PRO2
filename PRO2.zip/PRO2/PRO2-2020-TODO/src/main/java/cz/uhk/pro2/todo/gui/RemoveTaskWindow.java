package cz.uhk.pro2.todo.gui;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;

import cz.uhk.pro2.todo.model.TaskList;

import java.awt.*;

public class RemoveTaskWindow extends JFrame{
    private JButton btnRemove = new JButton("Odebrat úkol");
    private JPanel panel = new JPanel();
    private JTextField indexInput = new JTextField("Index");
    private TaskList list;
    private AbstractTableModel table;
    private JLabel lblUndoneTasks;

    public RemoveTaskWindow(TaskList list, AbstractTableModel table, JLabel lblUndoneTasks) {
        this.list = list;
        this.table = table;
        this.lblUndoneTasks = lblUndoneTasks;
        btnRemove.addActionListener(e -> removeTask());
        setTitle("Remove Task");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        panel.add(indexInput);
        panel.add(btnRemove);
        add(panel, BorderLayout.CENTER);
        pack();
    }

    private void removeTask(){
        list.removeTask(list.getTasks().get(Integer.parseInt(indexInput.getText())));
        lblUndoneTasks.setText("Počet nesplněných úkolů: " + list.getUndoneTasksCount());
        this.setVisible(false);
        table.fireTableDataChanged();
    }
}
