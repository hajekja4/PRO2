package cz.uhk.pro2.todo.gui;

import cz.uhk.pro2.todo.model.Task;
import cz.uhk.pro2.todo.model.TaskList;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import javax.swing.table.AbstractTableModel;

public class TasksTableModel extends AbstractTableModel {
    private TaskList taskList;

    public TasksTableModel(TaskList taskList) {
        this.taskList = taskList;
    }

    @Override
    public int getRowCount() {
        return taskList.getTasks().size();
    }

    @Override
    public int getColumnCount() {
        return 4;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Task task = taskList.getTasks().get(rowIndex);
        SimpleDateFormat formatter1 = new SimpleDateFormat("dd.MM.yyyy");
        SimpleDateFormat formatter2 = new SimpleDateFormat("yyyy-MM-dd");
        switch (columnIndex) {
            case 0: return task.getDescription();
            case 1: return formatter1.format(task.getDueDate());
            case 2: return task.isDone();
            case 3: return ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(formatter2.format(task.getDueDate()).toString()));
        }
        return ""; // tohle by se nemelo volat
    }

    @Override
    public String getColumnName(int column) {
        return new String[]{"Popis", "Datum", "Hotovo?", "Zbývá dnů"}[column];
    }
}
