package cz.uhk.pro2.todo;

import org.junit.Test;

import static org.junit.Assert.*;

public class TodoMainTest {
    @Test
    public void test1() {
        // priprava + operace
        String result = "abc";
        assertEquals(result, "abc");
    }
}